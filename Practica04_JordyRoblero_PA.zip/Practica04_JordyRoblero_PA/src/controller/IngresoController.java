package controller;

import java.util.ArrayList;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import model.Aportador;


public class IngresoController {
    private final ArrayList<Aportador> aportadores = new ArrayList<>();

    private static final Pattern CEDULA = Pattern.compile("(?i)(?:cédula|cedula|CI)\\s*(?:es\\s*)?[:]?\\s*(\\d+)");
    private static final Pattern CORREO = Pattern.compile("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
    private static final Pattern CORREO_CERCANO = Pattern.compile("(?i)correo\\s+(?!de\\b)([^,;\\s]+)");
    private static final Pattern MONTO = Pattern.compile("(?i)(\\$\\s*\\d+(?:[.,]\\d{1,2})?|\\d+(?:[.,]\\d{1,2})?\\s*(?:dólares|dolares|USD|\\$))");
    private static final Pattern NOMBRE_ANTES_CEDULA = Pattern.compile("([A-ZÁÉÍÓÚÑ][\\p{L}]+(?:\\s+[A-ZÁÉÍÓÚÑ][\\p{L}]+){1,4})\\s*,?\\s*(?:(?:con|su)\\s+)?(?:cédula|cedula|CI)");
    private static final Pattern NOMBRE_CON_TRATAMIENTO = Pattern.compile("(?i)(?:señor|señora)\\s+([A-ZÁÉÍÓÚÑ][\\p{L}]+\\s+[A-ZÁÉÍÓÚÑ][\\p{L}]+)");

    public void cargarYAnalizarArchivo(String ruta) throws IOException {
        String texto = Files.readString(Path.of(ruta), StandardCharsets.UTF_8);
        analizarTexto(texto);
    }

    public void analizarTexto(String texto) {
        aportadores.clear();

        String[] registros = texto.split("(?<=[.!?])\\s+(?=[A-ZÁÉÍÓÚÑ])");

        for (String registro : registros) {
            Matcher mCedula = CEDULA.matcher(registro);
            if (!mCedula.find()) {
                continue;
            }

            String cedula = mCedula.group(1);
            String antes = registro.substring(0, mCedula.start());
            Matcher mNombre = NOMBRE_ANTES_CEDULA.matcher(antes + registro.substring(mCedula.start(), mCedula.end()).replaceFirst("(?i)(?:cédula|cedula|CI)", "cédula"));
            String nombre = "No identificado";
            while (mNombre.find()) {
                nombre = mNombre.group(1).trim();
            }
            if (nombre.equals("No identificado")) {
                Matcher mNombreTratamiento = NOMBRE_CON_TRATAMIENTO.matcher(registro);
                if (mNombreTratamiento.find()) {
                    nombre = mNombreTratamiento.group(1).trim();
                }
            }

            Matcher mCorreo = CORREO.matcher(registro);
            String correo = mCorreo.find() ? mCorreo.group() : "";
            if (correo.isEmpty()) {
                Matcher correoCercano = CORREO_CERCANO.matcher(registro);
                if (correoCercano.find()) {
                    correo = correoCercano.group(1).trim();
                }
            }

            Matcher mMonto = MONTO.matcher(registro);
            String montoTexto = mMonto.find() ? mMonto.group() : "";
            double monto = convertirMonto(montoTexto);

            boolean cedulaValida = cedula.matches("\\d{10}");
            boolean correoValido = correo.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
            boolean montoValido = !montoTexto.isEmpty() && monto > 0;

            aportadores.add(new Aportador(nombre, cedula, correo, montoTexto, monto,
                    cedulaValida, correoValido, montoValido));
        }
    }

    private double convertirMonto(String texto) {
        if (texto == null || texto.isBlank()) return 0;
        String limpio = texto.replaceAll("(?i)dólares|dolares|USD|\\$", "")
                .trim().replace(",", ".");
        try {
            return Double.parseDouble(limpio);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public void modificarAportador(int indice, String nombre, String cedula, String correo, String montoTexto) {
        if (indice < 0 || indice >= aportadores.size()) {
            throw new IndexOutOfBoundsException("Selecciona un registro válido.");
        }
        double monto = convertirMonto(montoTexto);
        aportadores.get(indice).actualizar(nombre.trim(), cedula.trim(), correo.trim(), montoTexto.trim(), monto);
    }
    public void guardarEnArchivo(String ruta) throws IOException {
        StringBuilder contenido = new StringBuilder();
        contenido.append("REGISTROS DE INGRESOS ANALIZADOS\n");
        contenido.append("Nombre;Cédula;Correo;Monto;Validación\n");
        for (Aportador a : aportadores) {
            contenido.append(limpiarCampo(a.getNombre())).append(';')
                    .append(limpiarCampo(a.getCedula())).append(';')
                    .append(limpiarCampo(a.getCorreo())).append(';')
                    .append(String.format(Locale.US, "%.2f", a.getMonto())).append(';')
                    .append(a.getEstado()).append('\n');
        }
        Files.writeString(Path.of(ruta), contenido.toString(), StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING, StandardOpenOption.WRITE);
    }

    private String limpiarCampo(String valor) {
        if (valor == null) return "";
        return valor.replace(';', ',').replace('\n', ' ').replace('\r', ' ');
    }

    public ArrayList<Aportador> getAportadores() {
        return new ArrayList<>(aportadores);
    }

    public double getTotalValido() {
        return aportadores.stream().filter(Aportador::isRegistroValido)
                .mapToDouble(Aportador::getMonto).sum();
    }

    public int contarErroresCedula() {
        return (int) aportadores.stream().filter(a -> !a.isCedulaValida()).count();
    }

    public int contarErroresCorreo() {
        return (int) aportadores.stream().filter(a -> !a.isCorreoValido()).count();
    }

    public int contarErroresMonto() {
        return (int) aportadores.stream().filter(a -> !a.isMontoValido()).count();
    }
}
