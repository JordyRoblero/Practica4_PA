package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.io.File;
import java.text.DecimalFormat;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.table.DefaultTableModel;
import controller.IngresoController;
import model.Aportador;
import javax.swing.border.TitledBorder;
import javax.swing.border.EtchedBorder;

public class VentanaPrincipal extends JFrame {
    private final Color AZUL_OSCURO = new Color(91, 73, 105);
    private final Color AZUL = new Color(128, 101, 141);
    private final Color TURQUESA = new Color(113, 139, 131);
    private final Color FONDO = new Color(243, 240, 244);
    private final Color BLANCO = Color.WHITE;
    private final IngresoController controller = new IngresoController();
    private final DefaultTableModel modelo = new DefaultTableModel(
            new String[]{"Nombre", "Cédula", "Correo", "Monto", "Validación"}, 0) {
        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable tabla = new JTable(modelo);
    private final JLabel lblArchivo = new JLabel("Ningún archivo seleccionado");
    private final JLabel lblTotal = new JLabel("$0.00", SwingConstants.CENTER);
    private final JLabel lblCedulas = new JLabel("0", SwingConstants.CENTER);
    private final JLabel lblCorreos = new JLabel("0", SwingConstants.CENTER);
    private final JLabel lblMontos = new JLabel("0", SwingConstants.CENTER);
    private final DecimalFormat df = new DecimalFormat("0.00");
    private String rutaActual;
    public VentanaPrincipal() {
        configurarVentana();
        construirInterfaz();
        eventos();
    }
    private void configurarVentana() {
        setTitle("Sistema de Registro de Ingresos");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 680);
        setMinimumSize(new Dimension(900, 600));
        setLocationRelativeTo(null);
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}
    }
    private void construirInterfaz() {
        getContentPane().setLayout(new BorderLayout(12, 12));
        getContentPane().setBackground(new Color(128, 0, 128));
        JPanel encabezado = new JPanel(new BorderLayout());
        encabezado.setBackground(new Color(128, 0, 128));
        encabezado.setBorder(BorderFactory.createEmptyBorder(25, 22, 25, 22));
        JLabel titulo = new JLabel("REGISTRO Y VALIDACIÓN DE INGRESOS", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 23));
        titulo.setForeground(Color.WHITE);
        encabezado.add(titulo, BorderLayout.NORTH);
        getContentPane().add(encabezado, BorderLayout.NORTH);
        JPanel centro = new JPanel(new BorderLayout(8, 8));
        centro.setBackground(new Color(128, 0, 128));
        centro.setBorder(BorderFactory.createEmptyBorder(0, 22, 0, 22));
        JPanel acciones = new JPanel(new BorderLayout(10, 5));
        acciones.setBackground(new Color(128, 0, 128));
        JButton btnCargar = new JButton("Cargar archivo");
        JButton btnAnalizar = new JButton("Analizar registros");
        JButton btnLimpiar = new JButton("Limpiar");
        JButton btnModificar = new JButton("Modificar seleccionado");
        JButton btnGuardar = new JButton("Guardar archivo");
        btnCargar.setFocusPainted(false);
        btnAnalizar.setFocusPainted(false);
        btnLimpiar.setFocusPainted(false);
        btnModificar.setFocusPainted(false);
        btnGuardar.setFocusPainted(false);
        btnCargar.setBackground(AZUL);
        btnCargar.setForeground(new Color(0, 128, 255));
        btnAnalizar.setBackground(TURQUESA);
        btnAnalizar.setForeground(new Color(0, 128, 255));
        btnLimpiar.setBackground(new Color(145, 137, 150));
        btnLimpiar.setForeground(new Color(0, 128, 255));
        JPanel botones = new JPanel();
        botones.setBackground(new Color(128, 128, 192));
        botones.add(btnCargar);
        botones.add(btnAnalizar);
        botones.add(btnLimpiar);
        botones.add(btnModificar);
        botones.add(btnGuardar);
        acciones.add(botones, BorderLayout.WEST);
        lblArchivo.setFont(new Font("Arial", Font.ITALIC, 12));
        lblArchivo.setForeground(AZUL_OSCURO);
        acciones.add(lblArchivo, BorderLayout.SOUTH);
        centro.add(acciones, BorderLayout.NORTH);
        tabla.setRowHeight(27);
        tabla.setFont(new Font("Arial", Font.PLAIN, 12));
        tabla.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        tabla.getTableHeader().setBackground(AZUL_OSCURO);
        tabla.getTableHeader().setForeground(Color.WHITE);
        tabla.setBackground(new Color(255, 255, 255));
        tabla.setForeground(new Color(55, 50, 60));
        tabla.setGridColor(new Color(128, 128, 255));
        tabla.setSelectionBackground(new Color(226, 216, 234));
        tabla.setSelectionForeground(AZUL_OSCURO);
        tabla.setFillsViewportHeight(true);
        JScrollPane scroll = new JScrollPane(tabla);
        scroll.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, new Color(255, 255, 255), new Color(160, 160, 160)), "Registros encontrados", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
        centro.add(scroll, BorderLayout.CENTER);
        getContentPane().add(centro, BorderLayout.CENTER);
        JPanel resumen = new JPanel(new GridLayout(1, 4, 10, 0));
        resumen.setBackground(new Color(128, 0, 128));
        resumen.setBorder(BorderFactory.createEmptyBorder(0, 22, 20, 22));
        resumen.add(tarjeta("TOTAL DE INGRESOS VÁLIDOS", lblTotal, BLANCO, AZUL_OSCURO));
        resumen.add(tarjeta("ERRORES EN CÉDULAS", lblCedulas, BLANCO, new Color(181, 105, 105)));
        resumen.add(tarjeta("ERRORES EN CORREOS", lblCorreos, BLANCO, new Color(177, 139, 91)));
        resumen.add(tarjeta("ERRORES EN MONTOS", lblMontos, BLANCO, TURQUESA));
        getContentPane().add(resumen, BorderLayout.SOUTH);
        btnCargar.addActionListener(e -> cargarArchivo());
        btnAnalizar.addActionListener(e -> analizarArchivo());
        btnLimpiar.addActionListener(e -> limpiar());
        btnModificar.addActionListener(e -> modificarSeleccionado());
        btnGuardar.addActionListener(e -> guardarArchivo());
    }
    private JPanel tarjeta(String titulo, JLabel valor, Color fondo, Color colorTexto) {
        JPanel p = new JPanel(new BorderLayout(4, 8));
        p.setBackground(fondo);
        p.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(12, 8, 12, 8)));
        JLabel t = new JLabel(titulo, SwingConstants.CENTER);
        t.setFont(new Font("Arial", Font.BOLD, 10));
        t.setForeground(colorTexto);
        valor.setFont(new Font("Arial", Font.BOLD, 21));
        valor.setForeground(colorTexto);
        p.add(t, BorderLayout.NORTH);
        p.add(valor, BorderLayout.CENTER);
        return p;
    }
    private void eventos() {}
    private void cargarArchivo() {
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Seleccionar registro_ingresos.txt");
        int opcion = chooser.showOpenDialog(this);
        if (opcion == JFileChooser.APPROVE_OPTION) {
            File archivo = chooser.getSelectedFile();
            rutaActual = archivo.getAbsolutePath();
            lblArchivo.setText("Archivo: " + archivo.getName());
        }
    }
    private void analizarArchivo() {
        if (rutaActual == null) {
            JOptionPane.showMessageDialog(this, "Primero selecciona el archivo registro_ingresos.txt.",
                    "Archivo requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        try {
            controller.cargarYAnalizarArchivo(rutaActual);
            mostrarResultados();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "No se pudo leer el archivo:\n" + ex.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private void mostrarResultados() {
        modelo.setRowCount(0);
        for (Aportador a : controller.getAportadores()) {
            String monto = a.getMontoTexto().isBlank() ? "No encontrado" : a.getMontoTexto();
            modelo.addRow(new Object[]{
                    a.getNombre(),
                    a.getCedula(),
                    a.getCorreo().isBlank() ? "No encontrado" : a.getCorreo(),
                    monto,
                    a.getEstado()
            });
        }
        lblTotal.setText("$" + df.format(controller.getTotalValido()));
        lblCedulas.setText(String.valueOf(controller.contarErroresCedula()));
        lblCorreos.setText(String.valueOf(controller.contarErroresCorreo()));
        lblMontos.setText(String.valueOf(controller.contarErroresMonto()));
    }
    private void modificarSeleccionado() {
        int fila = tabla.getSelectedRow();
        if (fila < 0) {
            JOptionPane.showMessageDialog(this, "Selecciona primero un registro de la tabla.",
                    "Registro requerido", JOptionPane.WARNING_MESSAGE);
            return;
        }
        Aportador a = controller.getAportadores().get(fila);
        JTextField txtNombre = new JTextField(a.getNombre());
        JTextField txtCedula = new JTextField(a.getCedula());
        JTextField txtCorreo = new JTextField(a.getCorreo());
        JTextField txtMonto = new JTextField(a.getMontoTexto());
        JPanel formulario = new JPanel(new GridLayout(4, 2, 8, 8));
        formulario.add(new JLabel("Nombre:")); formulario.add(txtNombre);
        formulario.add(new JLabel("Cédula:")); formulario.add(txtCedula);
        formulario.add(new JLabel("Correo:")); formulario.add(txtCorreo);
        formulario.add(new JLabel("Monto:")); formulario.add(txtMonto);
        int opcion = JOptionPane.showConfirmDialog(this, formulario, "Modificar registro",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (opcion == JOptionPane.OK_OPTION) {
            if (txtNombre.getText().isBlank()) {
                JOptionPane.showMessageDialog(this, "El nombre no puede quedar vacío.",
                        "Dato requerido", JOptionPane.WARNING_MESSAGE);
                return;
            }
            try {
                controller.modificarAportador(fila, txtNombre.getText(), txtCedula.getText(),
                        txtCorreo.getText(), txtMonto.getText());
                mostrarResultados();
                tabla.setRowSelectionInterval(fila, fila);
                JOptionPane.showMessageDialog(this, "Registro modificado. Recuerda guardar los cambios en un archivo.",
                        "Modificación", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "No se pudo modificar el registro: " + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void guardarArchivo() {
        if (controller.getAportadores().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Primero carga y analiza un archivo.",
                    "Sin registros", JOptionPane.WARNING_MESSAGE);
            return;
        }
        JFileChooser chooser = new JFileChooser();
        chooser.setDialogTitle("Guardar registros modificados");
        chooser.setSelectedFile(new File("registro_ingresos_modificado.txt"));
        int opcion = chooser.showSaveDialog(this);
        if (opcion == JFileChooser.APPROVE_OPTION) {
            File archivo = chooser.getSelectedFile();
            if (archivo.exists()) {
                int confirmar = JOptionPane.showConfirmDialog(this,
                        "El archivo ya existe. ¿Deseas reemplazarlo?", "Confirmar reemplazo",
                        JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
                if (confirmar != JOptionPane.YES_OPTION) return;
            }
            try {
                controller.guardarEnArchivo(archivo.getAbsolutePath());
                JOptionPane.showMessageDialog(this, "Los registros se guardaron correctamente en:\n"
                        + archivo.getAbsolutePath(), "Archivo guardado", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "No se pudo guardar el archivo:\n" + ex.getMessage(),
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    private void limpiar() {
        modelo.setRowCount(0);
        rutaActual = null;
        lblArchivo.setText("Ningún archivo seleccionado");
        lblTotal.setText("$0.00");
        lblCedulas.setText("0");
        lblCorreos.setText("0");
        lblMontos.setText("0");
    }
}
