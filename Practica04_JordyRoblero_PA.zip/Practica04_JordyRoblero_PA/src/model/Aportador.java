package model;

public class Aportador {
    private String nombre;
    private String cedula;
    private String correo;
    private String montoTexto;
    private double monto;
    private boolean cedulaValida;
    private boolean correoValido;
    private boolean montoValido;

    public Aportador(String nombre, String cedula, String correo, String montoTexto,
                     double monto, boolean cedulaValida, boolean correoValido, boolean montoValido) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.correo = correo;
        this.montoTexto = montoTexto;
        this.monto = monto;
        this.cedulaValida = cedulaValida;
        this.correoValido = correoValido;
        this.montoValido = montoValido;
    }

    public void actualizar(String nombre, String cedula, String correo, String montoTexto, double monto) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.correo = correo;
        this.montoTexto = montoTexto;
        this.monto = monto;
        this.cedulaValida = cedula != null && cedula.matches("\\d{10}");
        this.correoValido = correo != null && correo.matches("[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}");
        this.montoValido = montoTexto != null && !montoTexto.isBlank() && monto > 0;
    }

    public String getNombre() { return nombre; }
    public String getCedula() { return cedula; }
    public String getCorreo() { return correo; }
    public String getMontoTexto() { return montoTexto; }
    public double getMonto() { return monto; }
    public boolean isCedulaValida() { return cedulaValida; }
    public boolean isCorreoValido() { return correoValido; }
    public boolean isMontoValido() { return montoValido; }
    public boolean isRegistroValido() { return cedulaValida && correoValido && montoValido; }

    public String getEstado() {
        if (isRegistroValido()) return "VÁLIDO";
        StringBuilder s = new StringBuilder("ERROR: ");
        if (!cedulaValida) s.append("Cédula ");
        if (!correoValido) s.append("Correo ");
        if (!montoValido) s.append("Monto ");
        return s.toString().trim();
    }
}
